from django.apps import AppConfig


class GalleryConfig(AppConfig):
    name = 'gallery'
